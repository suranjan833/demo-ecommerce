const String appName = 'eShop';

const String packageName = 'com.eshopsingle.customer';
const String androidLink = 'https://play.google.com/store/apps/details?id=';

const String iosPackage = 'com.wrteam.eshop';
const String iosLink = 'your ios link here';
const String appStoreId = '123456789';

const String deepLinkUrlPrefix = 'https://eshopwrteamin.page.link';
const String deepLinkName = 'eshop.com';

const int timeOut = 50;
const int perPage = 10;

//Token ExpireTime in minutes & issuer name
const int tokenExpireTime = 5;
const String issuerName = 'eshop';

const String defaultCountryCode = 'IN';

const String baseUrl = 'https://eshopweb.store/app/v1/api/';
const String jwtKey = "26c24b4b956fd695fbd5fd85a883a7a0abe36043";

const int decimalPoints = 2;
